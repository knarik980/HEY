class Product < ApplicationRecord
end