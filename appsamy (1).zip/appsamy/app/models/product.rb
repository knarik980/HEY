class Product <ApplicationRecord
end